<?php
            $dbhost = "localhost";
            $dbUser = "root";
            $dbPass = "";
            $dbName = "foodcollector";

            //creating mysql connection
            $conn = new mysqli($dbhost,$dbUser,$dbPass,$dbName);

