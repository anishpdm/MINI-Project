<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eyebank";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$mysqli=new mysqli($servername, $username, $password, $dbname);
?>